
//{{BLOCK(winImage)

//======================================================================
//
//	winImage, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 38400 = 38912
//
//	Time-stamp: 2021-12-15, 06:00:22
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_WINIMAGE_H
#define GRIT_WINIMAGE_H

#define winImageBitmapLen 38400
extern const unsigned short winImageBitmap[19200];

#define winImagePalLen 512
extern const unsigned short winImagePal[256];

#endif // GRIT_WINIMAGE_H

//}}BLOCK(winImage)
