
//{{BLOCK(level0foreground2)

//======================================================================
//
//	level0foreground2, 256x512@4, 
//	+ palette 6 entries, not compressed
//	+ 230 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x64 
//	Total size: 12 + 7360 + 4096 = 11468
//
//	Time-stamp: 2021-12-14, 11:16:03
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL0FOREGROUND2_H
#define GRIT_LEVEL0FOREGROUND2_H

#define level0foreground2TilesLen 7360
extern const unsigned short level0foreground2Tiles[3680];

#define level0foreground2MapLen 4096
extern const unsigned short level0foreground2Map[2048];

#define level0foreground2PalLen 12
extern const unsigned short level0foreground2Pal[6];

#endif // GRIT_LEVEL0FOREGROUND2_H

//}}BLOCK(level0foreground2)
