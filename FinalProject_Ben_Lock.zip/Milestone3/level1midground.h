
//{{BLOCK(level1midground)

//======================================================================
//
//	level1midground, 512x256@4, 
//	+ palette 1 entries, not compressed
//	+ 165 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 2 + 5280 + 4096 = 9378
//
//	Time-stamp: 2021-12-04, 22:42:09
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1MIDGROUND_H
#define GRIT_LEVEL1MIDGROUND_H

#define level1midgroundTilesLen 5280
extern const unsigned short level1midgroundTiles[2640];

#define level1midgroundMapLen 4096
extern const unsigned short level1midgroundMap[2048];

#define level1midgroundPalLen 2
extern const unsigned short level1midgroundPal[2];

#endif // GRIT_LEVEL1MIDGROUND_H

//}}BLOCK(level1midground)
