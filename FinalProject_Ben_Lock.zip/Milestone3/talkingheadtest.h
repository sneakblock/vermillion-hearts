
//{{BLOCK(talkingheadtest)

//======================================================================
//
//	talkingheadtest, 116x152@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 17632 = 18144
//
//	Time-stamp: 2021-12-03, 23:27:33
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TALKINGHEADTEST_H
#define GRIT_TALKINGHEADTEST_H

#define talkingheadtestBitmapLen 17632
extern const unsigned short talkingheadtestBitmap[8816];

#define talkingheadtestPalLen 512
extern const unsigned short talkingheadtestPal[256];

#endif // GRIT_TALKINGHEADTEST_H

//}}BLOCK(talkingheadtest)
