
//{{BLOCK(level3collisionmap)

//======================================================================
//
//	level3collisionmap, 256x256@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 65536 = 66048
//
//	Time-stamp: 2021-12-15, 03:47:08
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL3COLLISIONMAP_H
#define GRIT_LEVEL3COLLISIONMAP_H

#define level3collisionmapBitmapLen 65536
extern const unsigned short level3collisionmapBitmap[32768];

#define level3collisionmapPalLen 512
extern const unsigned short level3collisionmapPal[256];

#endif // GRIT_LEVEL3COLLISIONMAP_H

//}}BLOCK(level3collisionmap)
