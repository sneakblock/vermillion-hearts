// trackA sound made by wav2c

extern const unsigned int trackA_sampleRate;
extern const unsigned int trackA_length;
extern const signed char trackA_data[];
