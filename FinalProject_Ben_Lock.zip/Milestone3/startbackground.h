
//{{BLOCK(startbackground)

//======================================================================
//
//	startbackground, 256x256@4, 
//	+ palette 2 entries, not compressed
//	+ 59 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 4 + 1888 + 2048 = 3940
//
//	Time-stamp: 2021-12-04, 23:49:22
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTBACKGROUND_H
#define GRIT_STARTBACKGROUND_H

#define startbackgroundTilesLen 1888
extern const unsigned short startbackgroundTiles[944];

#define startbackgroundMapLen 2048
extern const unsigned short startbackgroundMap[1024];

#define startbackgroundPalLen 4
extern const unsigned short startbackgroundPal[2];

#endif // GRIT_STARTBACKGROUND_H

//}}BLOCK(startbackground)
