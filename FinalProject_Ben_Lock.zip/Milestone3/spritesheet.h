
//{{BLOCK(SPRITESHEET)

//======================================================================
//
//	SPRITESHEET, 256x256@4, 
//	+ palette 16 entries, not compressed
//	+ 1024 tiles not compressed
//	Total size: 32 + 32768 = 32800
//
//	Time-stamp: 2021-12-15, 13:24:46
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPRITESHEET_H
#define GRIT_SPRITESHEET_H

#define SPRITESHEETTilesLen 32768
extern const unsigned short SPRITESHEETTiles[16384];

#define SPRITESHEETPalLen 32
extern const unsigned short SPRITESHEETPal[16];

#endif // GRIT_SPRITESHEET_H

//}}BLOCK(SPRITESHEET)
