
//{{BLOCK(level1foreground)

//======================================================================
//
//	level1foreground, 512x256@4, 
//	+ palette 9 entries, not compressed
//	+ 198 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 18 + 6336 + 4096 = 10450
//
//	Time-stamp: 2021-12-04, 22:42:33
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1FOREGROUND_H
#define GRIT_LEVEL1FOREGROUND_H

#define level1foregroundTilesLen 6336
extern const unsigned short level1foregroundTiles[3168];

#define level1foregroundMapLen 4096
extern const unsigned short level1foregroundMap[2048];

#define level1foregroundPalLen 18
extern const unsigned short level1foregroundPal[10];

#endif // GRIT_LEVEL1FOREGROUND_H

//}}BLOCK(level1foreground)
