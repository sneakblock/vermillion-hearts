
//{{BLOCK(masterseer)

//======================================================================
//
//	masterseer, 116x92@8, 
//	+ palette 16 entries, not compressed
//	+ bitmap not compressed
//	Total size: 32 + 10672 = 10704
//
//	Time-stamp: 2021-12-15, 13:00:10
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MASTERSEER_H
#define GRIT_MASTERSEER_H

#define masterseerBitmapLen 10672
extern const unsigned short masterseerBitmap[5336];

#define masterseerPalLen 32
extern const unsigned short masterseerPal[16];

#endif // GRIT_MASTERSEER_H

//}}BLOCK(masterseer)
