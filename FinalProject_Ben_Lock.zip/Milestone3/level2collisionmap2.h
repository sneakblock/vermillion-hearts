
//{{BLOCK(level2collisionmap2)

//======================================================================
//
//	level2collisionmap2, 256x256@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 65536 = 66048
//
//	Time-stamp: 2021-12-15, 03:32:20
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL2COLLISIONMAP2_H
#define GRIT_LEVEL2COLLISIONMAP2_H

#define level2collisionmap2BitmapLen 65536
extern const unsigned short level2collisionmap2Bitmap[32768];

#define level2collisionmap2PalLen 512
extern const unsigned short level2collisionmap2Pal[256];

#endif // GRIT_LEVEL2COLLISIONMAP2_H

//}}BLOCK(level2collisionmap2)
