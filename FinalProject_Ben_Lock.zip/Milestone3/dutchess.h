
//{{BLOCK(dutchess)

//======================================================================
//
//	dutchess, 116x92@8, 
//	+ palette 16 entries, not compressed
//	+ bitmap not compressed
//	Total size: 32 + 10672 = 10704
//
//	Time-stamp: 2021-12-15, 12:40:38
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_DUTCHESS_H
#define GRIT_DUTCHESS_H

#define dutchessBitmapLen 10672
extern const unsigned short dutchessBitmap[5336];

#define dutchessPalLen 32
extern const unsigned short dutchessPal[16];

#endif // GRIT_DUTCHESS_H

//}}BLOCK(dutchess)
