
//{{BLOCK(instructionsforeground)

//======================================================================
//
//	instructionsforeground, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 596 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 19072 + 2048 = 21632
//
//	Time-stamp: 2021-12-15, 06:10:43
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_INSTRUCTIONSFOREGROUND_H
#define GRIT_INSTRUCTIONSFOREGROUND_H

#define instructionsforegroundTilesLen 19072
extern const unsigned short instructionsforegroundTiles[9536];

#define instructionsforegroundMapLen 2048
extern const unsigned short instructionsforegroundMap[1024];

#define instructionsforegroundPalLen 512
extern const unsigned short instructionsforegroundPal[256];

#endif // GRIT_INSTRUCTIONSFOREGROUND_H

//}}BLOCK(instructionsforeground)
