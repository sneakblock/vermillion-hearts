
//{{BLOCK(seerscreen)

//======================================================================
//
//	seerscreen, 256x256@4, 
//	+ 101 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 3232 + 2048 = 5280
//
//	Time-stamp: 2021-12-13, 18:16:55
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SEERSCREEN_H
#define GRIT_SEERSCREEN_H

#define seerscreenTilesLen 3232
extern const unsigned short seerscreenTiles[1616];

#define seerscreenMapLen 2048
extern const unsigned short seerscreenMap[1024];

#endif // GRIT_SEERSCREEN_H

//}}BLOCK(seerscreen)
