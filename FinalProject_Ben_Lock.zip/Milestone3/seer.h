
//{{BLOCK(seer)

//======================================================================
//
//	seer, 116x92@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 10672 = 11184
//
//	Time-stamp: 2021-12-06, 21:19:45
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SEER_H
#define GRIT_SEER_H

#define seerBitmapLen 10672
extern const unsigned short seerBitmap[5336];

#define seerPalLen 512
extern const unsigned short seerPal[256];

#endif // GRIT_SEER_H

//}}BLOCK(seer)
