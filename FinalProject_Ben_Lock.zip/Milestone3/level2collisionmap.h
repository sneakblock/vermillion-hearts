
//{{BLOCK(level2collisionmap)

//======================================================================
//
//	level2collisionmap, 256x256@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 65536 = 66048
//
//	Time-stamp: 2021-12-14, 23:08:21
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL2COLLISIONMAP_H
#define GRIT_LEVEL2COLLISIONMAP_H

#define level2collisionmapBitmapLen 65536
extern const unsigned short level2collisionmapBitmap[32768];

#define level2collisionmapPalLen 512
extern const unsigned short level2collisionmapPal[256];

#endif // GRIT_LEVEL2COLLISIONMAP_H

//}}BLOCK(level2collisionmap)
