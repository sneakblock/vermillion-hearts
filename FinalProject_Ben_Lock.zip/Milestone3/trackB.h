// trackB sound made by wav2c

extern const unsigned int trackB_sampleRate;
extern const unsigned int trackB_length;
extern const signed char trackB_data[];
