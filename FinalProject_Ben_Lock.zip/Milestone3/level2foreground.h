
//{{BLOCK(level2foreground)

//======================================================================
//
//	level2foreground, 256x256@8, 
//	+ palette 32 entries, not compressed
//	+ 777 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 64 + 49728 + 2048 = 51840
//
//	Time-stamp: 2021-12-14, 23:12:51
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL2FOREGROUND_H
#define GRIT_LEVEL2FOREGROUND_H

#define level2foregroundTilesLen 49728
extern const unsigned short level2foregroundTiles[24864];

#define level2foregroundMapLen 2048
extern const unsigned short level2foregroundMap[1024];

#define level2foregroundPalLen 64
extern const unsigned short level2foregroundPal[32];

#endif // GRIT_LEVEL2FOREGROUND_H

//}}BLOCK(level2foreground)
