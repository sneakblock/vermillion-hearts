
//{{BLOCK(startmidground)

//======================================================================
//
//	startmidground, 256x256@4, 
//	+ palette 8 entries, not compressed
//	+ 249 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 16 + 7968 + 2048 = 10032
//
//	Time-stamp: 2021-12-04, 23:44:14
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTMIDGROUND_H
#define GRIT_STARTMIDGROUND_H

#define startmidgroundTilesLen 7968
extern const unsigned short startmidgroundTiles[3984];

#define startmidgroundMapLen 2048
extern const unsigned short startmidgroundMap[1024];

#define startmidgroundPalLen 16
extern const unsigned short startmidgroundPal[8];

#endif // GRIT_STARTMIDGROUND_H

//}}BLOCK(startmidground)
