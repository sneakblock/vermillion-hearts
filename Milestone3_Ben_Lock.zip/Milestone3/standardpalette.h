
//{{BLOCK(standardpalette)

//======================================================================
//
//	standardpalette, 8192x32@8, 
//	+ palette 256 entries, not compressed
//	Total size: 512 = 512
//
//	Time-stamp: 2021-11-26, 16:07:40
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STANDARDPALETTE_H
#define GRIT_STANDARDPALETTE_H

#define standardpalettePalLen 512
extern const unsigned short standardpalettePal[256];

#endif // GRIT_STANDARDPALETTE_H

//}}BLOCK(standardpalette)
