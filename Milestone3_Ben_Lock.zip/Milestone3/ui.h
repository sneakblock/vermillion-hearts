


// Custom Game Colors
#define NUMCOLORS 3

enum {BLACKID=(256-NUMCOLORS), BLACKID, WHITEID, GRAYID};

extern unsigned short colors[NUMCOLORS];