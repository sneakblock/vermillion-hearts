
//{{BLOCK(level1foreground)

//======================================================================
//
//	level1foreground, 512x256@8, 
//	+ palette 256 entries, not compressed
//	+ 604 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 38656 + 4096 = 43264
//
//	Time-stamp: 2021-11-26, 21:13:25
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1FOREGROUND_H
#define GRIT_LEVEL1FOREGROUND_H

#define level1foregroundTilesLen 38656
extern const unsigned short level1foregroundTiles[19328];

#define level1foregroundMapLen 4096
extern const unsigned short level1foregroundMap[2048];

#define level1foregroundPalLen 512
extern const unsigned short level1foregroundPal[256];

#endif // GRIT_LEVEL1FOREGROUND_H

//}}BLOCK(level1foreground)
