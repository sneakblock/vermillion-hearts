
//{{BLOCK(level1background)

//======================================================================
//
//	level1background, 512x256@8, 
//	+ 538 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 34432 + 4096 = 38528
//
//	Time-stamp: 2021-11-26, 16:32:39
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1BACKGROUND_H
#define GRIT_LEVEL1BACKGROUND_H

#define level1backgroundTilesLen 34432
extern const unsigned short level1backgroundTiles[17216];

#define level1backgroundMapLen 4096
extern const unsigned short level1backgroundMap[2048];

#endif // GRIT_LEVEL1BACKGROUND_H

//}}BLOCK(level1background)
