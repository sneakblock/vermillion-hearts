
//{{BLOCK(level1midground)

//======================================================================
//
//	level1midground, 512x256@8, 
//	+ 162 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 10368 + 4096 = 14464
//
//	Time-stamp: 2021-11-26, 16:31:22
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1MIDGROUND_H
#define GRIT_LEVEL1MIDGROUND_H

#define level1midgroundTilesLen 10368
extern const unsigned short level1midgroundTiles[5184];

#define level1midgroundMapLen 4096
extern const unsigned short level1midgroundMap[2048];

#endif // GRIT_LEVEL1MIDGROUND_H

//}}BLOCK(level1midground)
