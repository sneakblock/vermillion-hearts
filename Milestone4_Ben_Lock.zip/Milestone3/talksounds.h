// talksounds sound made by wav2c

extern const unsigned int talksounds_sampleRate;
extern const unsigned int talksounds_length;
extern const signed char talksounds_data[];
