extern NPC plantMerchant;
extern NPC seer;
extern NPC knight;

void initNPCS();
NPC* initPlantMerchant();
NPC* initSeer();
NPC* initKnight();

void openGate();
