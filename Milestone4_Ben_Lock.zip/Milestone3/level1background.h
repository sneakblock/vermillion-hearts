
//{{BLOCK(level1background)

//======================================================================
//
//	level1background, 512x256@4, 
//	+ palette 2 entries, not compressed
//	+ 538 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 4 + 17216 + 4096 = 21316
//
//	Time-stamp: 2021-12-04, 22:41:28
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1BACKGROUND_H
#define GRIT_LEVEL1BACKGROUND_H

#define level1backgroundTilesLen 17216
extern const unsigned short level1backgroundTiles[8608];

#define level1backgroundMapLen 4096
extern const unsigned short level1backgroundMap[2048];

#define level1backgroundPalLen 4
extern const unsigned short level1backgroundPal[2];

#endif // GRIT_LEVEL1BACKGROUND_H

//}}BLOCK(level1background)
