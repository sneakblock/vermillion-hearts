
//{{BLOCK(selector)

//======================================================================
//
//	selector, 4x8@8, 
//	+ bitmap not compressed
//	Total size: 32 = 32
//
//	Time-stamp: 2021-12-04, 18:30:15
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

const unsigned short selectorBitmap[16] __attribute__((aligned(4)))=
{
	0xFFFF,0xFFFF,0xFFFF,0xFFFF,0xFFFE,0xFFFF,0xFEFF,0xFFFE,
	0xFFFF,0xFEFF,0xFFFF,0xFEFF,0xFEFF,0xFFFE,0xFFFE,0xFFFF,
};

//}}BLOCK(selector)
