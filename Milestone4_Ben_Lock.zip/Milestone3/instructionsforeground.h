
//{{BLOCK(instructionsforeground)

//======================================================================
//
//	instructionsforeground, 256x256@4, 
//	+ palette 16 entries, not compressed
//	+ 623 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 32 + 19936 + 2048 = 22016
//
//	Time-stamp: 2021-12-05, 01:28:10
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_INSTRUCTIONSFOREGROUND_H
#define GRIT_INSTRUCTIONSFOREGROUND_H

#define instructionsforegroundTilesLen 19936
extern const unsigned short instructionsforegroundTiles[9968];

#define instructionsforegroundMapLen 2048
extern const unsigned short instructionsforegroundMap[1024];

#define instructionsforegroundPalLen 32
extern const unsigned short instructionsforegroundPal[16];

#endif // GRIT_INSTRUCTIONSFOREGROUND_H

//}}BLOCK(instructionsforeground)
