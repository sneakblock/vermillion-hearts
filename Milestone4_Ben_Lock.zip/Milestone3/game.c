#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#include "game.h"
#include "standardpalette.h"
#include "level1foreground.h"
#include "level1midground.h"
#include "level1background.h"
#include "level1collisionmap.h"
#include "spritesheet.h"
#include "talkingheadtest.h"
#include "talkingheadtest2.h"
#include "levels.h"
#include "npcs.h"

int gateUnlocked;

NPC* currentTarget;
LEVEL* currentLevel;
LEVEL level0;
LEVEL level1;
PLAYER player;

//NPC stuff Milestone 3
// NPC npcs[MAX_NPCS_PER_LEVEL];

int hOff;
int vOff;

// unsigned char* level1collisionmap = level1collisionmapBitmap;

void initGame() {

    initLevels();
    currentLevel = &level0;
    initPlayer();
    // initNPCS();

    gateUnlocked = 0;

}

void updateGame() {

    updatePlayer();
    updateNPCS();
    if (currentLevel->animFunc) {
        currentLevel->animFunc();
    }
    checkForConvoBools();

    if (player.worldRow < 5) {
        goToWin();
    }

}

void checkForConvoBools() {

    for (int i = 0; i < currentLevel->numNPCS; i++) {

        if (currentLevel->npcs[i]->convoBoolSatisfied) {

            if (currentLevel->npcs[i]->convoFunc) {
                currentLevel->npcs[i]->convoFunc();
                currentLevel->npcs[i]->convoBoolSatisfied = 0;
            }

        }

    }

}

void drawGame() {

    drawPlayer();
    drawNPCS();

    //Maybe don't do this during a glitch?
    waitForVBlank();

    DMANow(3, shadowOAM, OAM, 128 * 4);

    REG_BG0HOFF = hOff;
    REG_BG0VOFF = vOff;

    REG_BG1HOFF = hOff / 2;
    REG_BG1VOFF = vOff / 2;

    REG_BG2HOFF = hOff / 3;
    REG_BG2VOFF = vOff / 3;
    

    // REG_BG2HOFF = hOff / 8;
    // REG_BG2VOFF = vOff / 8;

}



void initLevels() {

    initPause();
    initLevel0();
    initLevel1();

}

void initPlayer() {

    player.currentEidolon = CLOUD;
    player.rdel = 1;
    player.cdel = 1;
    player.width = 8;
    player.height = 16;

    player.hide = 0;

    player.aniCounter = 0;
    player.framesToWait = 20;
    player.aniState = 0;
    player.numStates = 1;
    player.prevAniState = 0;
    player.curFrame = 0;
    player.numFrames = 3;
    player.gameSpriteTileIDx = 0;
    player.gameSpriteTileIDy = 0;

}

void loadLevel(LEVEL* level, int resetsPlayerPos) {

    REG_BG0CNT = level->levelSize | BG_4BPP | BG_CHARBLOCK(0) | BG_SCREENBLOCK(30);
    DMANow(3, level->foregroundTiles, &CHARBLOCK[0], (level->foregroundTilesLen) / 2);
    DMANow(3, level->foregroundMap, &SCREENBLOCK[30], (level->foregroundMapLen) / 2);
    DMANow(3, level->foregroundPal, PALETTE, level->foregroundPalLen / 2);

    if (level->midgroundTiles) {
        REG_BG1CNT = level->levelSize | BG_4BPP | BG_CHARBLOCK(1) | BG_SCREENBLOCK(28);
        DMANow(3, level->midgroundTiles, &CHARBLOCK[1], level->midgroundTilesLen / 2);
        DMANow(3, level->midgroundMap, &SCREENBLOCK[28], level->midgroundMapLen / 2);
        DMANow(3, level->midgroundPal, &PALETTE[level->foregroundPalLen / 2], level->midgroundPalLen / 2);
    }

    if (level->backgroundTiles) {
        REG_BG2CNT = level->levelSize | BG_4BPP | BG_CHARBLOCK(2) | BG_SCREENBLOCK(26);
        DMANow(3, level->backgroundTiles, &CHARBLOCK[2], level->backgroundTilesLen / 2);
        DMANow(3, level->backgroundMap, &SCREENBLOCK[26], level->backgroundMapLen / 2);
        DMANow(3, level->backgroundPal, &PALETTE[(level->foregroundPalLen / 2) + (level->midgroundPalLen / 2)], level->backgroundPalLen / 2);
    }

    if (resetsPlayerPos) {
        player.worldCol = level->playerWorldSpawnCol;
        player.worldRow = level->playerWorldSpawnRow;
        hOff = level->initHOff;
        vOff = level->initVOff;
    }

    // for (int i = 0; i < MAX_NPCS_PER_LEVEL; i++) {
    //     if (&level->npcs[i] != NULL) {
    //         loadNPC(&level->npcs[i]);
    //     }
    // }

    // currentLevel = level;

}

void loadNPC(NPC* npc) {

    npc->active = 1;

}



void updatePlayer() {

    player.isMoving = 0;

    if(BUTTON_HELD(BUTTON_UP)) {
        if (player.worldRow > 0 && currentLevel->collisionMap[OFFSET(player.worldCol, player.worldRow - player.rdel, currentLevel->worldPixelWidth)] && 
            currentLevel->collisionMap[OFFSET(player.worldCol + player.width - 1, player.worldRow - player.rdel, currentLevel->worldPixelWidth)]) {
                
                player.worldRow = player.worldRow - player.rdel;
                player.isMoving = 1;

            if (vOff > 0 && (player.worldRow - vOff) <= SCREENHEIGHT / 2) {
                // Update background offset variable if the above is true
                vOff--;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_DOWN)) {
        if (player.worldRow + player.height < currentLevel->worldPixelHeight && currentLevel->collisionMap[OFFSET(player.worldCol, player.worldRow + player.height - 1 + player.rdel, currentLevel->worldPixelWidth)] && 
            currentLevel->collisionMap[OFFSET(player.worldCol + player.width - 1, player.worldRow + player.height - 1 + player.rdel, currentLevel->worldPixelWidth)]) {
                player.worldRow = player.worldRow + player.rdel;
                player.isMoving = 1;

            // Update player's world position if the above is true



            if (vOff < currentLevel->worldPixelHeight - SCREENHEIGHT && (player.worldRow - vOff) > SCREENHEIGHT / 2) {
                // Update background offset variable if the above is true
                vOff++;
                
            }
        }
    }
    if(BUTTON_HELD(BUTTON_LEFT)) {
        if (player.worldCol > 0 && currentLevel->collisionMap[OFFSET(player.worldCol - player.cdel, player.worldRow, currentLevel->worldPixelWidth)] && 
            currentLevel->collisionMap[OFFSET(player.worldCol - player.cdel, player.worldRow + player.height - 1, currentLevel->worldPixelWidth)]) {
                player.worldCol = player.worldCol - player.cdel;
                player.isMoving = 1;

            // Update player's world position if the above is true

            if (hOff > 0 && (player.worldCol - hOff) <= SCREENWIDTH / 2) {
                hOff--;
                
            }
        }
    }
    if(BUTTON_HELD(BUTTON_RIGHT)) {
        if (player.worldCol + player.width < currentLevel->worldPixelWidth && currentLevel->collisionMap[OFFSET(player.worldCol + player.width - 1 + player.cdel, player.worldRow, currentLevel->worldPixelWidth)] && 
            currentLevel->collisionMap[OFFSET(player.worldCol + player.width - 1 + player.cdel, player.worldRow + player.height - 1, currentLevel->worldPixelWidth)]) {

            player.worldCol = player.worldCol + player.cdel;
            player.isMoving = 1;

            if (hOff < currentLevel->worldPixelWidth - SCREENWIDTH && (player.worldCol - hOff) > SCREENWIDTH / 2) {

                // Update background offset variable if the above is true
                hOff++;
                

            }
        }
    }

    if (BUTTON_PRESSED(BUTTON_START)) {
        goToPause();
    }

    // for (int i = 0; i < MAX_NPCS_PER_LEVEL - 1; i++) {
    //     if (collision(player.worldCol, player.worldRow, player.width, player.height, npcs[i].worldCol, npcs[i].worldRow, npcs[i].width, npcs[i].height)) {
    //         goToLose();
    //     }
    // }

    // if (player.worldCol == 0) {
    //     goToWin();
    // }

    // if (BUTTON_PRESSED(BUTTON_A)) {
    //     glitchVisuals (40);
    // }

    for (int i = 0; i < currentLevel->numNPCS; i++) {
        //Temp solution
        if (collision(player.worldCol, player.worldRow, player.width, player.height, currentLevel->npcs[i]->worldCol, currentLevel->npcs[i]->worldRow, currentLevel->npcs[i]->width, currentLevel->npcs[i]->height) && BUTTON_PRESSED(BUTTON_A)) {
            currentTarget = currentLevel->npcs[i];
            goToDialogue();
        }
    }

    animatePlayer();

}

void updateNPCS() {

    // for (int i = 0; i < MAX_NPCS_PER_LEVEL - 1; i++) {

    //     switch (npcs[i].intendedDirection) {
    //         case UP:
    //             if (npcs[i].worldRow > 0 && level1collisionmap[OFFSET(npcs[i].worldCol, npcs[i].worldRow - npcs[i].rdel, currentLevel->worldPixelWidth)] && 
    //             level1collisionmap[OFFSET(npcs[i].worldCol + npcs[i].width - 1, npcs[i].worldRow - npcs[i].rdel, currentLevel->worldPixelWidth)]) {
    //                 npcs[i].worldRow -= npcs[i].rdel;
    //             } else {
    //                 npcs[i].intendedDirection = rand() % (3 + 1 - 0) + 0;
    //             }
    //             break;
    //         case DOWN:
    //             if (npcs[i].worldRow < currentLevel->worldPixelHeight - npcs[i].height && level1collisionmap[OFFSET(npcs[i].worldCol, npcs[i].worldRow + npcs[i].height - 1 + npcs[i].rdel, currentLevel->worldPixelWidth)] && 
    //             level1collisionmap[OFFSET(npcs[i].worldCol + npcs[i].width - 1, npcs[i].worldRow + npcs[i].height - 1 + npcs[i].rdel, currentLevel->worldPixelWidth)]) {
    //                 npcs[i].worldRow += npcs[i].rdel;
    //             } else {
    //                 npcs[i].intendedDirection = rand() % (3 + 1 - 0) + 0;
    //             }
    //             break;
    //         case LEFT:
    //             if (npcs[i].worldCol > 0 && level1collisionmap[OFFSET(npcs[i].worldCol - npcs[i].cdel, npcs[i].worldRow, currentLevel->worldPixelWidth)] && 
    //             level1collisionmap[OFFSET(npcs[i].worldCol - npcs[i].cdel, npcs[i].worldRow + npcs[i].height - 1, currentLevel->worldPixelWidth)]) {
    //             npcs[i].worldCol -= npcs[i].cdel;
    //             } else {
    //                 npcs[i].intendedDirection = rand() % (3 + 1 - 0) + 0;
    //             }
    //             break;
    //         case RIGHT:
    //             if (npcs[i].worldCol < currentLevel->worldPixelWidth - npcs[i].width && level1collisionmap[OFFSET(npcs[i].worldCol + npcs[i].width - 1 + npcs[i].cdel, npcs[i].worldRow, currentLevel->worldPixelWidth)] && 
    //             level1collisionmap[OFFSET(npcs[i].worldCol + npcs[i].width - 1 + npcs[i].cdel, npcs[i].worldRow + npcs[i].height - 1, currentLevel->worldPixelWidth)]) {
    //             npcs[i].worldCol += npcs[i].cdel;
    //             } else {
    //                 npcs[i].intendedDirection = rand() % (3 + 1 - 0) + 0;
    //             }
    //             break;
    //     }
    // }

    animateNPCS();

}

void animatePlayer() {

        // Set previous state to current state
        // player.prevAniState = player.aniState;
        // player.aniState = IDLE;

        if(player.aniCounter % player.framesToWait == 0) {
            player.curFrame = (player.curFrame + 1) % player.numFrames;
            player.aniCounter = 0;
        }

        // Control movement and change animation state
        // if(BUTTON_HELD(BUTTON_UP))
        //     player.aniState = UP;
        // if(BUTTON_HELD(BUTTON_DOWN))
        //     player.aniState = DOWN;
        // if(BUTTON_HELD(BUTTON_LEFT))
        //     player.aniState = LEFT;
        // if(BUTTON_HELD(BUTTON_RIGHT))
        //     player.aniState = RIGHT;

        // If the player aniState is idle, frame is player standing
        // if (player.aniState == IDLE) {
        //     player.curFrame = 0;
        //     player.aniCounter = 0;
        //     player.aniState = player.prevAniState;
        // } else {
            if (player.isMoving) {
                player.aniCounter++;
            }
            
        // }

}

void animateNPCS() {

        for (int i = 0; i < currentLevel->numNPCS; i++) {
            // currentLevel->npcs[i]->aniState = currentLevel->npcs[i]->intendedDirection;
            if (currentLevel->npcs[i]->aniCounter % 20 == 0) {
            currentLevel->npcs[i]->curFrame = (currentLevel->npcs[i]->curFrame + 1) % currentLevel->npcs[i]->numFrames;
            currentLevel->npcs[i]->aniCounter = 0;
            }
            currentLevel->npcs[i]->aniCounter++;
        }

}

void drawPlayer() {

    if (player.hide) {
        shadowOAM[0].attr0 |= ATTR0_HIDE;
    } else {
        shadowOAM[0].attr0 = (ROWMASK & (player.worldRow - vOff)) | ATTR0_TALL | ATTR0_4BPP;
        shadowOAM[0].attr1 = (COLMASK & (player.worldCol - hOff)) | ATTR1_TINY;
        shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((player.gameSpriteTileIDx) + (player.aniState * (player.width / 8)), (player.gameSpriteTileIDy) + (player.curFrame * (player.height / 8)));
        // shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0, 0);
    }
}

void drawNPCS() {
    for (int i = 0; i < currentLevel->numNPCS; i++) {
        if (currentLevel->npcs[i]->hide) {
        shadowOAM[i + 1].attr0 |= ATTR0_HIDE;
        } else {
        shadowOAM[i + 1].attr0 = (currentLevel->npcs[i]->worldRow - vOff) | ATTR0_TALL | ATTR0_4BPP;
        shadowOAM[i + 1].attr1 = (currentLevel->npcs[i]->worldCol - hOff) | ATTR1_TINY;
        shadowOAM[i + 1].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((currentLevel->npcs[i]->gameSpriteTileIDx) + (currentLevel->npcs[i]->aniState * (currentLevel->npcs[i]->width / 8)), (currentLevel->npcs[i]->gameSpriteTileIDy) + (currentLevel->npcs[i]->curFrame * (currentLevel->npcs[i]->height / 8)));
        // shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0, 0);
    }
    }
}

// void glitchVisuals(int duration) {

//     int counter = 0;

//     while (counter < duration) {
//         for (int i = 0; i < MAX_NPCS_PER_LEVEL - 1; i++) {
//             npcs[i].cdel = 0;
//             npcs[i].rdel = 0;
//         }

//         DMANow(3, currentLevel->midgroundTiles, &CHARBLOCK[1], currentLevel->midgroundTilesLen / 2);
//         DMANow(3, currentLevel->midgroundMap, &SCREENBLOCK[27], currentLevel->midgroundMapLen / 2);

//         DMANow(3, currentLevel->backgroundTiles, &CHARBLOCK[2], currentLevel->backgroundTilesLen / 2);
//         DMANow(3, currentLevel->backgroundMap, &SCREENBLOCK[24], currentLevel->backgroundMapLen / 2);
//         waitForVBlank();
//         counter++;
        
//     }

//     for (int i = 0; i < MAX_NPCS_PER_LEVEL - 1; i++) {
//             npcs[i].cdel = 1;
//             npcs[i].rdel = 1;
//         }

//     DMANow(3, currentLevel->defaultPalette, PALETTE, 256);
//     DMANow(3, currentLevel->foregroundTiles, &CHARBLOCK[0], (currentLevel->foregroundTilesLen) / 2);
//     DMANow(3, currentLevel->foregroundMap, &SCREENBLOCK[30], (currentLevel->foregroundMapLen) / 2);

//     DMANow(3, SPRITESHEETTiles, &CHARBLOCK[4], SPRITESHEETTilesLen / 2);
//     DMANow(3, SPRITESHEETPal, SPRITEPALETTE, SPRITESHEETPalLen / 2);
//     hideSprites();
//     DMANow(3, shadowOAM, OAM, 512);

// }



