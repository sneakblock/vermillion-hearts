
//{{BLOCK(talkingheadtest2)

//======================================================================
//
//	talkingheadtest2, 116x152@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 17632 = 18144
//
//	Time-stamp: 2021-12-04, 17:36:29
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TALKINGHEADTEST2_H
#define GRIT_TALKINGHEADTEST2_H

#define talkingheadtest2BitmapLen 17632
extern const unsigned short talkingheadtest2Bitmap[8816];

#define talkingheadtest2PalLen 512
extern const unsigned short talkingheadtest2Pal[256];

#endif // GRIT_TALKINGHEADTEST2_H

//}}BLOCK(talkingheadtest2)
