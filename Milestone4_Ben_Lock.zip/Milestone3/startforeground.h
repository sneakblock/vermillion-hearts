
//{{BLOCK(startforeground)

//======================================================================
//
//	startforeground, 256x256@4, 
//	+ palette 5 entries, not compressed
//	+ 179 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 10 + 5728 + 2048 = 7786
//
//	Time-stamp: 2021-12-05, 00:33:11
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTFOREGROUND_H
#define GRIT_STARTFOREGROUND_H

#define startforegroundTilesLen 5728
extern const unsigned short startforegroundTiles[2864];

#define startforegroundMapLen 2048
extern const unsigned short startforegroundMap[1024];

#define startforegroundPalLen 10
extern const unsigned short startforegroundPal[6];

#endif // GRIT_STARTFOREGROUND_H

//}}BLOCK(startforeground)
