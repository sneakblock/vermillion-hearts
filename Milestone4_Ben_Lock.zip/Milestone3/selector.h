
//{{BLOCK(selector)

//======================================================================
//
//	selector, 4x8@8, 
//	+ bitmap not compressed
//	Total size: 32 = 32
//
//	Time-stamp: 2021-12-04, 18:30:15
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SELECTOR_H
#define GRIT_SELECTOR_H

#define selectorBitmapLen 32
extern const unsigned short selectorBitmap[16];

#endif // GRIT_SELECTOR_H

//}}BLOCK(selector)
