
//{{BLOCK(level0collisionmap2)

//======================================================================
//
//	level0collisionmap2, 256x512@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 131072 = 131584
//
//	Time-stamp: 2021-12-06, 23:47:37
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL0COLLISIONMAP2_H
#define GRIT_LEVEL0COLLISIONMAP2_H

#define level0collisionmap2BitmapLen 131072
extern const unsigned short level0collisionmap2Bitmap[65536];

#define level0collisionmap2PalLen 512
extern const unsigned short level0collisionmap2Pal[256];

#endif // GRIT_LEVEL0COLLISIONMAP2_H

//}}BLOCK(level0collisionmap2)
