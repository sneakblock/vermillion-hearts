
//{{BLOCK(knight)

//======================================================================
//
//	knight, 116x92@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 10672 = 11184
//
//	Time-stamp: 2021-12-06, 23:29:12
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_KNIGHT_H
#define GRIT_KNIGHT_H

#define knightBitmapLen 10672
extern const unsigned short knightBitmap[5336];

#define knightPalLen 512
extern const unsigned short knightPal[256];

#endif // GRIT_KNIGHT_H

//}}BLOCK(knight)
